set "rai1=180090"
set "rai2=180116"
set "rai3=180117"
set "med=87127"
set "sport1=4145"
set "sport2=179975"
set "rai5=72382"
set "premium=72383"
set "gulp=4119"
set "storia=24269"
set "yoyo=72384"
set "movie=72381"
set "news=1"
set "scuola=24268"
set "euro=113784"
set "rai4=75708"
set "radio1=162834"
set "radio2=162063"
set "radio3=162841"
set "diff4=173799"
set "diff5=173832"
set "webradio6=174078"
set "webradio7=174083"
set "webradio8=174086"
set "isoradio=173875"
set "parlamento=173879"
set "italiaradio=173887"
set "zatswf=http://zattoo.com/static/player.swf?"
set "urlr=http://mediapolis.rai.it/relinker/relinkerServlet.htm?cont="
set "head=viaurl: www.rai.tv"
set "vuoto=2>nul"
set "vlc=c:\progra~1\videolan\vlc\vlc"




wget -q -O temp.txt "http://zeroradio.altervista.org/zerol.php"
find "Italia1"<temp.txt>chann.txt
erase temp.txt
set /p chan=<chann.txt
erase chann.txt
call flv -v -W "%zatswf%" -r "%chan%" -q | %vlc% -